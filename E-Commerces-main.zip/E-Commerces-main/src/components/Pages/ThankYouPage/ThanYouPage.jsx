import React from "react";

function ThanYouPage() {
  return <div>ThanYouPage</div>;
}

export default ThanYouPage;
