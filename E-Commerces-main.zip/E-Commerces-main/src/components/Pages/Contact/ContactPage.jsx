import React from "react";

function ContactPage() {
  return <div>ContactPage</div>;
}

export default ContactPage;
