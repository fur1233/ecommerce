import React from "react";

function CategoryPage() {
  return <div>CategoryPage</div>;
}

export default CategoryPage;
